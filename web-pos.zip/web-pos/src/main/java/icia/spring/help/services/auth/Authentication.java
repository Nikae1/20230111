package icia.spring.help.services.auth;

import java.util.ArrayList;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import icia.spring.help.bean.CategoriesBean;
import icia.spring.help.bean.GroupBean;
import lombok.extern.slf4j.Slf4j;

/**/
@Service
@Slf4j
public class Authentication {
	@Autowired
	private SqlSessionTemplate session;
	public Authentication() {}
	
	public void backController(int serviceCode, Model model) {
		switch(serviceCode) {
		case 11:
			this.groupNameDuplicateCheckCtl(model);
			break;
			
		case 12:
			this.memberJoinCtl(model);
			break;
			
		case 13:
			
			break;
			
		}
	}

	public void backController(int serviceCode, ModelAndView mav) {
		switch(serviceCode) {
		case 1:
			break;
		}
	}
	
	/* 중복체크 검사 */
	private void groupNameDuplicateCheckCtl(Model model) {
		GroupBean group = ((GroupBean)model.getAttribute("group"));
	//	log.info("{}", ((GroupBean)model.getAttribute("group")).getGroupName());
	
		
		log.info("{}", (int)this.session.selectOne("isGroupName", group));
	
		/* Temp에 중복검사 // 동시에 같은 groupName을 사용하는 경우를 대비 */
	if(!this.convertToBoolean(this.session.selectOne("isGroupName", group))) {
		
		
		if(this.convertToBoolean(this.session.insert("insTemp", group))) {
		}else {group.setMessage("NetWork Error: 네트워크가 불안정합니다. 잠시 후 다시 이용해주세요.");}
	
	}
	else {group.setMessage("GroupName Error: 이미 사용중인 그룹명입니다. 다른 이름을 사용해주세요.");}
	
	}
	
	private void memberJoinCtl(Model model) {
		String[][] levInfo = {{"L1", "그룹대표"},{"L2", "매니저"},{"L3", "직원"}};
		GroupBean group = ((GroupBean)model.getAttribute("group"));
		CategoriesBean category = null;
		ArrayList<CategoriesBean> categoryList = null;
		
		log.info("{}", group);
		
		if(this.convertToBoolean(this.session.insert("insGroup", group))) {
			if(this.convertToBoolean(this.session.insert("delTemp", group))) {
				if(this.convertToBoolean(this.session.insert("insStore", group))) {
					
					/* Default CategoriesInfo*/
					for(String[] lev : levInfo) {
						categoryList = new ArrayList<CategoriesBean>();
						/* 카테고리에 들어갈 직원등급과 명칭을 미리 [INS]시켜주기위한
						 * add를 사용할 경우 덮어씌기가 안되므로, 들어있는 값을 반드시 clear를 해줘야 한다 */
						if(categoryList.size() !=0) categoryList.clear();
						
						category = new CategoriesBean();
						category.setLevCode(lev[0]);
						category.setLevName(lev[1]);
						categoryList.add(category);
						
						group.getStoreInfoList().get(0).setCateList(categoryList);
						this.session.insert("insCategory", group);
					}
					

					
						if(this.convertToBoolean(this.session.insert("insEmp", group))) {
							
						}else {group.setMessage("회원가입 오류: emp에 오류가 발생하였습니다.");}				
				}else {group.setMessage("회원가입 오류: store에 오류가 발생하였습니다.");}
			}else {group.setMessage("회원가입 오류: Temp delete 오류가 발생하였습니다.");}
		}else {group.setMessage("회원가입 오류: group에 오류가 발생하였습니다.");}
		
	}
	
	
	private boolean convertToBoolean(int value) {
		return (value >= 1)? true : false;
	}
	
	
}
