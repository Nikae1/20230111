package icia.spring.help;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import icia.spring.help.bean.CategoriesBean;
import icia.spring.help.bean.EmployeesBean;
import icia.spring.help.bean.GroupBean;
import icia.spring.help.bean.StoreBean;
import icia.spring.help.services.auth.Authentication;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class APIcontroller {

	@Autowired
	private Authentication auth;
	
//	@PostMapping("/GroupDupChk")
//	/* ﻿
//	HttpServlet을 이용하지 않고, DispatcherServlet으로 변경하여 원래사용하던
//	request --> HTTPRequest를 이용하지 않고, 이제는 Model이라는 곳에 Request 담는다.
//	*/
//	public GroupBean groupDuplicateCheck(Model model, @ModelAttribute GroupBean group) {
//		
//		
//		
//		
//		
//		
//		model.addAttribute("group", group);
//		auth.backController(11, model);
//		
//		//group.setMessage("그룹명 중복: 사용 중인 그룹명입니다. 다른 그룹명을 이용해주세요.");
//		log.info(group.getGroupName());
//		//log.info("< {} >", group);
//	
//		return (GroupBean)model.getAttribute("group");
//	}

	@PostMapping("/GroupDupChk")
	public GroupBean groupDuplicateCheck(Model model, @ModelAttribute GroupBean group) {
		ArrayList<StoreBean> storeList = new ArrayList<StoreBean>();
		StoreBean store = new StoreBean();
		ArrayList<CategoriesBean> categoryList = new ArrayList<CategoriesBean>();
		CategoriesBean category = new CategoriesBean();
		ArrayList<EmployeesBean> empList = new ArrayList<EmployeesBean>();
		EmployeesBean emp = new EmployeesBean();
		
		storeList.add(store);
		group.setStoreInfoList(storeList);
		categoryList.add(category);
		group.getStoreInfoList().get(0).setCateList(categoryList);
		empList.add(emp);
		group.getStoreInfoList().get(0).setEmpList(empList);
		
		
		
		model.addAttribute("group", group);
		auth.backController(11, model);
		
		//group.setMessage("그룹명 중복: 사용 중인 그룹명입니다. 다른 그룹명을 이용해주세요.");
		log.info(group.getGroupName());
		//log.info("< {} >", group);
		
		return (GroupBean)model.getAttribute("group");
	}
	
	@PostMapping("/MemberJoin")
	public GroupBean groupBeanCheck(Model model, @ModelAttribute GroupBean group) {
		model.addAttribute("group", group);
		
		log.info(group.getGroupName());
		log.info(group.getGroupCeo());
		log.info(group.getGroupPin());

		auth.backController(12, model);
		
		return (GroupBean)model.getAttribute("group");
	}
	
	
}
