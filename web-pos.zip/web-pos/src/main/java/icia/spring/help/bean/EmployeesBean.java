package icia.spring.help.bean;

import java.util.ArrayList;

import lombok.Data;

@Data
public class EmployeesBean {
	private String empCode;
	private String empLevCode;
	private String empName;
	private String empPin;
	private String empImgCode;
	private ArrayList<AccessLogBean> accessList;
	
	
}
